# skulski-dice-roller
# Author: Kevin Skulski
# Contact: kevinpskulski@lewisu.edu
# Class: Software Engineering
# Description: This application rolls 5 die.
# This project is an HTML application which requires the files diceRoller.html, diceRoller.css, and diceRoller.js.
