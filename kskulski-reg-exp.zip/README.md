# skulski-reg-exp
# Author: Kevin Skulski
# Contact: kevinpskulski@lewisu.edu
# Class: Software Engineering
# Description: Searches for a matching expression between the two inputs.
# This project is an HTML application which requires the file RegExpTester.html.
